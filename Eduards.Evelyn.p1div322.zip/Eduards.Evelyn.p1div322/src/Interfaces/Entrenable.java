package Interfaces;

public interface Entrenable {
    void entrenar();
}
