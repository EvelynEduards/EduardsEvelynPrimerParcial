package Model;

public class AlgoritmoGenetico extends Modelo {
    private double tasaMutacion;

    public AlgoritmoGenetico(String nombre, String laboratorio, TipoDatos tipoDatos,double tasaMutacion) {
        super(nombre, laboratorio, tipoDatos);
        validarTasaMutacion(tasaMutacion);
        this.tasaMutacion = tasaMutacion;
    }

    private void validarTasaMutacion(double tasa){
        if(tasa < 0){
            throw new IllegalArgumentException("La tasa de mutacion debe ser mayor a 0");
        }
    }
     

    @Override
    public String toString() {
        return super.toString() + ", Tasa de mutacion ideal: " + tasaMutacion;
    }
    
    
    
    
    
    
}
