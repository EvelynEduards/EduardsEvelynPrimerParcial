package Model;

import Excepcion.ModeloDuplicadoException;


public class EduardsEvelynP1div322 {

    public static void main(String[] args) {
         SistemaModelos sistema = new SistemaModelos();

        // 1. Agregar modelos
        try {
            RedNeuronal rn1 = new RedNeuronal("Clasificador de Imagenes", "Lab1", TipoDatos.DATOS_NUMERICOS, 10);
            sistema.agregarModelo(rn1);

            // Modelo duplicado
            RedNeuronal rn2 = new RedNeuronal("Clasificador de Imagenes", "Lab1", TipoDatos.DATOS_NUMERICOS, 10);
            sistema.agregarModelo(rn2);
        } catch (ModeloDuplicadoException e) {
            System.out.println("Error: " + e.getMessage());
        }

        try {
            sistema.agregarModelo(new RedNeuronal("Analizador de texto", "Lab2", TipoDatos.DATOS_TEXTUALES, 8));
            sistema.agregarModelo(new ArbolDecision("Riesgo", "Lab3", TipoDatos.DATOS_NUMERICOS, "gini"));
            sistema.agregarModelo(new ArbolDecision("ClasificadorSpam", "Lab2", TipoDatos.DATOS_TEXTUALES, "entropia"));
        } catch (ModeloDuplicadoException e) {
            System.out.println("Error: " + e.getMessage());
        }

        try {
            sistema.agregarModelo(new AlgoritmoGenetico("Optimizador genetico", "Lab1", TipoDatos.DATOS_NUMERICOS, 5.5));
        } catch (ModeloDuplicadoException e) {
            System.out.println("Error: " + e.getMessage());
        }

        // 2. Mostrar modelos registrados
        sistema.mostrarModelos();

        // 3. Entrenar modelos
        System.out.println("Entrenando modelos: ");
        sistema.entrenarModelos();

        // 4. Filtrar modelos por tipo de dato
        System.out.println("Filtrando por tipo de dato ... ");
        sistema.filtrarPorTipoDatos(TipoDatos.DATOS_NUMERICOS);
    }
}
