package Model;

import Interfaces.Entrenable;

public class RedNeuronal extends Modelo implements Entrenable {
    private int maxCapas;
    
    public RedNeuronal(String nombre, String laboratorio, TipoDatos tipoDatos, int capasMaximas) {
        super(nombre, laboratorio, tipoDatos);
        validarCantCapas(capasMaximas);
        maxCapas = capasMaximas;
    }

    private void validarCantCapas(int capas){
        if(capas < 0){
            throw new IllegalArgumentException("La cantidad de capas no puede ser menor a 0");
        }
    }
    
    @Override
    public void entrenar() {
        System.out.println("Entrenando red neuronal con el nombre: " + getNombre());
    }

    @Override
    public String toString() {
        return super.toString() + " Capas maximas = " + maxCapas;
    }
    
    
}
