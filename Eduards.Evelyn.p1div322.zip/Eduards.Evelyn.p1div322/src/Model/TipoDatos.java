package Model;

public enum TipoDatos {
    DATOS_NUMERICOS,
    DATOS_TEXTUALES
}
