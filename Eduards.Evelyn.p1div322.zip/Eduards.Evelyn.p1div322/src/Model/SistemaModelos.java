package Model;

import Excepcion.ModeloDuplicadoException;
import Interfaces.Entrenable;
import java.util.ArrayList;
import java.util.List;

public class SistemaModelos {
    private List<Modelo> modelos;
    
    public SistemaModelos(){
        modelos = new ArrayList<>();
    }
    
    private void validarModelo(Modelo m){
        if(m == null){
            throw new NullPointerException("No hay modelo");
     }
        if (modelos.contains(m)){ //compara usando el equals sobreescrito
            throw new ModeloDuplicadoException();
        }
    }
     
    public void agregarModelo(Modelo modelo){
        validarModelo(modelo);
        modelos.add(modelo);
    }
    
    private void validarHayModelos(){
        if(modelos.isEmpty()){
            throw new IllegalStateException("No hay modelos registrados");
    }
    }
    
    public void mostrarModelos(){
        validarHayModelos();
        System.out.println("Los modelos registrados son: ");
            for (Modelo m : modelos){
                System.out.println(m);
        }
    }
    
    
    public void entrenarModelos(){
        validarHayModelos();
        for(Modelo m : modelos) {
            if (m instanceof Entrenable){
                ((Entrenable)m).entrenar();
        } else {
            System.out.println("El modelo: " + m.getNombre() + " no necesita entrenamiento");
            }
        }
    }
    
        
    public List<Modelo> filtrarPorTipoDatos(TipoDatos tipo) {
        List<Modelo> filtrados = new ArrayList<>();

        for (Modelo m : modelos) {
            if (m.getTipoDatos() == tipo) {
                filtrados.add(m);
                System.out.println(m);
                System.out.println("--------------------------");
            }
        }

        return filtrados;
    }
    
    
}
