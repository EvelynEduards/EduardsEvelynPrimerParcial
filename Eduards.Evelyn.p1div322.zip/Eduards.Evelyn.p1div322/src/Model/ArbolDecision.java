package Model;

import Interfaces.Entrenable;

public class ArbolDecision extends Modelo implements Entrenable {
    private String criterioDivision;

    public ArbolDecision(String nombre, String laboratorio, TipoDatos tipoDatos,String criterioDivision) {
        super(nombre, laboratorio, tipoDatos);
        validarCriterioDivision(criterioDivision);
        this.criterioDivision = criterioDivision;
    }

    private void validarCriterioDivision(String criterio){
        if(criterio == ""){
            throw new IllegalArgumentException("Ingrese un criterio");
        }
    }
    
    @Override
    public void entrenar() {
        System.out.println("Entrenando Arbol de decision: " + getNombre() + " con " + getTipoDatos());
    }

    @Override
    public String toString() {
        return super.toString() + ", Criterio de division: " + criterioDivision;
    }
    
    
}
