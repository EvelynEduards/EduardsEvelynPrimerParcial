package Model;

public abstract class Modelo {
    private final String nombre;
    private final String laboratorio;
    private TipoDatos tipoDatos;

    public Modelo(String nombre, String laboratorio, TipoDatos tipoDatos) {
        this.nombre = nombre;
        this.laboratorio = laboratorio;
        this.tipoDatos = tipoDatos;
    }

    public String getNombre() {
        return nombre;
    }

    public String getLaboratorio() {
        return laboratorio;
    }

    public TipoDatos getTipoDatos() {
        return tipoDatos;
    }
    
    @Override
    public boolean equals (Object obj){
    if (obj == null || !(obj instanceof Modelo m)){
        return false;
    } return this.nombre.equals(m.nombre) && this.laboratorio.equals(m.laboratorio);
    }
    
    @Override
    public int hashCode(){
    return java.util.Objects.hash(nombre,laboratorio);
    }
    

    @Override
    public String toString() {
        return "Modelo: " + " Nombre = " + nombre + ", Laboratorio = " + laboratorio + ", Tipo de datos = " + tipoDatos;
    }
    
    
}
